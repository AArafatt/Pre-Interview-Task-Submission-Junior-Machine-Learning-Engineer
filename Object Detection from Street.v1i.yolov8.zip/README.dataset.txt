# Object Detection from Street > 2025-02-07 1:59pm
https://universe.roboflow.com/arafat-9nbvx/object-detection-from-street

Provided by a Roboflow user
License: CC BY 4.0

